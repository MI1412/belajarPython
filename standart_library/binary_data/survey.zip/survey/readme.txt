﻿=== Survey ===
Plugin Name: Survey
Contributors: seosbg
Plugin URI: http://seosthemes.com/survey/
Tags: Survey, Plugin Test, psychology test, personality test, personality quizzes, answer, Assessment, learning, question, quiz, test, exam, personality quiz, poll, product survey, questionnaire, quiz, survey, Survey Plugin, Survey WordPress Plugin, feedback, feedback form, qualitative survey, survey form.
Requires at least: 4.3.1
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KWSVPW2F8C7FW
Tested up to: 4.3.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Survey is easy to use – Include the Shortcode in your website. The plugin will send you an auto-email.

== Description ==

Survey is easy to use – Include the Shortcode in your website. The plugin will send you an auto-email.
To learn more about the Survey please see Plugin URI. See screenshot examples at http://seosthemes.com/survey/

= Shortcodes: =

Insert `[Survey]` on a page to display a form to add citations. 

 
== Frequently Asked Questions ==

= Is there a tutorial? =
See the <a href="http://seosthemes.com/survey/">Tutorial</a>

= Where can I find documentation on the plugin? =
Refer the <a href="http://seosthemes.com/survey/">Plugin Site</a>

== Installation ==

= Install via Plugins > Install New =
1. Search for "Survey"
2. Click the "Install Now" link
3. Click "Activate Plugin"

= Via ZIP / FTP =
1. Unzip the ZIP file and drop the folder straight into your wp-content/plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==

1. Admin Panel view of submitted form data.

== Changelog ==

= 1.0 =
* Initial release of plugin

== Upgrade Notice ==

= 1.0 =
Initial Release